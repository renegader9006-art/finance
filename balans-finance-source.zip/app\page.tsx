import { getChatGPTUser } from "./chatgpt-auth";
import { FinanceDashboard } from "./finance-dashboard";

export const dynamic = "force-dynamic";

export default async function Home() {
  const user = await getChatGPTUser();
  return (
    <FinanceDashboard
      user={user ? { displayName: user.displayName, email: user.email } : { displayName: "Гость", email: "Локальный просмотр" }}
      signedIn={Boolean(user)}
    />
  );
}
